# Online Portfolio
This Repository Contains the work I have done up until now. It is putting the skills I have learnt up till now to use.

## Live Link
https://mogammadtaariqbardien.github.io/new_online_portfolio/index.html

## Prevalent Technologies Used

 - CSS
 - SCSS
 - Bulma

### Other Technologies Used

Technologies and Tools Used:

```
Languages:

- CSS
- HTML
- SCSS

```
```
Tools:

- VS Code
- GitBash

```

### Changelog

2018-10-11:
- Base folders  added
- Readme Created
- Live Link Created
- Index File Created

2018-11-26
- Added framework
- Some Styling
- Added Images

2018-11-27
- Added hover effects
- Updated Readme

2018-11-30
- Added extra columns
- Added more information
- Changed some styling

2018-12-03
- Updated Readme
- Added Commenting
- Fixed Responsive issues
- Added some colour styling

2018-12-04
- Fixed minor responsive issues

## Contributors

Mogammad Taariq Bardien - 2018
